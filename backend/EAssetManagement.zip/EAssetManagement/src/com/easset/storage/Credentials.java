package com.easset.storage;

public class Credentials {
	public String url = "jdbc:mysql://localhost:3306/eassetdb";
	public String username = "root";
	public String password = "password";
}
