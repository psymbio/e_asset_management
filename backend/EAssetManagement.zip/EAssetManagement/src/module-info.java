/**
 * 
 */
/**
 * 
 */
module EAssetManagement {
	requires java.sql;
}